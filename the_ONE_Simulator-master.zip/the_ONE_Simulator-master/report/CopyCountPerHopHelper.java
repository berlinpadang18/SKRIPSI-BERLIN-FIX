/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package report;

/**
 *
 * @author Afra Rian
 */
public class CopyCountPerHopHelper {
    
    public int hopCount;
    
    public int copyMsg;

    public CopyCountPerHopHelper(int h, int c) {hopCount = h; copyMsg = c;}
    
}
